#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/image.hpp>
#include <image_transport/image_transport.hpp>
#include <cv_bridge/cv_bridge.h>
#include <opencv2/opencv.hpp>
#include <std_srvs/srv/set_bool.hpp>
#include <chrono>
#include <ctime>

class CameraPublisherNode : public rclcpp::Node
{
	public:
	    CameraPublisherNode()
	    : Node("camera_publisher"), count_(0)
	    {
	    this->declare_parameter<int>("camera_width", 640);
		this->declare_parameter<int>("camera_height", 480);
		this->declare_parameter<int>("rotation_angle", 180);  // grados
		this->declare_parameter<int>("frame_rate", 15);     // Hz

		this->get_parameter("camera_width", width);
		this->get_parameter("camera_height", height);
		this->get_parameter("rotation_angle", rotation_angle);
	   	this->get_parameter("frame_rate", frame_rate);
	   
	    cap_.open("/dev/video0");
		if (!cap_.isOpened()) {
		    RCLCPP_ERROR(this->get_logger(), "❌ No se pudo abrir la cámara");
		    rclcpp::shutdown();
		    return;
		}

	   cap_.set(cv::CAP_PROP_FRAME_WIDTH, width);
           cap_.set(cv::CAP_PROP_FRAME_HEIGHT, height);
 
  	   auto interval = std::chrono::milliseconds(static_cast<int>(1000.0 / frame_rate));
           timer_ = this->create_wall_timer(interval, std::bind(&CameraPublisherNode::publish_frame, this));
    	   //image_transport::ImageTransport it(this->shared_from_this());

	   publisher_ = this->create_publisher<sensor_msgs::msg::Image>("camera_topic",10);
	   
	   recording_service_ = this->create_service<std_srvs::srv::SetBool>("toggle_recording",
            std::bind(&CameraPublisherNode::handle_recording_request, this, std::placeholders::_1, std::placeholders::_2)
        );
        RCLCPP_INFO(this->get_logger(), " Nodo de cámara iniciado correctamente.");
	   }

	private:
		void publish_frame()    
		{
		cv::Mat frame;
		cap_ >> frame;
		if (frame.empty())
		{
			RCLCPP_WARN(this->get_logger(), "⚠️ Frame vacío recibido, ignorando.");
			return;
		}
		if(rotation_angle != 0.0) {
			cv::Point2f center(frame.cols / 2.0F, frame.rows / 2.0F);
			cv::Mat rot_mat = cv::getRotationMatrix2D(center, rotation_angle, 1.0);
			cv::warpAffine(frame, frame, rot_mat, frame.size());
		}
		std_msgs::msg::Header header;
		header.stamp = this->now();
		header.frame_id = "camera_frame";
		
		auto msg = cv_bridge::CvImage(header, "bgr8" , frame).toImageMsg();
		publisher_->publish(*msg);
		
		if (recording_in_progress && video_writer_.isOpened()) {
            	video_writer_.write(frame);
		
			}
		}
		
		void handle_recording_request(
			const std::shared_ptr<std_srvs::srv::SetBool::Request> request,
			std::shared_ptr<std_srvs::srv::SetBool::Response> response)
		    {
			if (request->data && !recording_in_progress) {
			    std::string filename = "video_" + std::to_string(std::time(nullptr)) + ".avi";
			    video_writer_.open(filename, cv::VideoWriter::fourcc('M','J','P','G'), frame_rate, cv::Size(width, height));

			    if (!video_writer_.isOpened()) {
				response->success = false;
				response->message = " No se pudo abrir el archivo de video.";
				return;
			    }

			    recording_in_progress = true;
			    response->success = true;
			    response->message = " Grabación iniciada.";
			    RCLCPP_INFO(this->get_logger(), " Grabación iniciada.");
			} else if (!request->data && recording_in_progress) {
			    video_writer_.release();
			    recording_in_progress = false;
			    response->success = true;
			    response->message = " Grabación detenida.";
			    RCLCPP_INFO(this->get_logger(), " Grabación detenida.");
			} else {
			    response->success = false;
			    response->message = " Estado de grabación no cambiado.";
			}
		    }
		
		rclcpp::TimerBase::SharedPtr timer_;
		rclcpp::Publisher<sensor_msgs::msg::Image>::SharedPtr publisher_;
		rclcpp::Service<std_srvs::srv::SetBool>::SharedPtr recording_service_;
		cv::VideoCapture cap_;
		cv::VideoWriter video_writer_;
		size_t count_;
		int width, height, rotation_angle, frame_rate;
		bool recording_in_progress = false;
};
		
int main(int argc, char** argv) {
    rclcpp::init(argc, argv);
    auto node = std::make_shared<CameraPublisherNode>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
